﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;

/*
 * https://www.hayneedle.com/product/lifestylesolutionsharvardsofa.cfm
 */

namespace eFunitureShop.Models
{
    public class SeedData
    {
        public static void EnsurePopulated(IApplicationBuilder app)
        {
            ApplicationDbContext context = app.ApplicationServices.GetRequiredService<ApplicationDbContext>();
            context.Database.Migrate();
            if (!context.Products.Any())
            {
                context.Products.AddRange(

                    new Product
                    {
                        Name = "Elegant Lighting Corona 9800",
                        Delivery = "Y",
                        Specifications = "Assembly: Some Assembly Required@Brand@ Elegant Furniture & Lighting@Bulb Type@Candelabra@Bulb Wattage@40",
                        Description = "Dimensions: 10L x 10W x 8H in. " +
                            "Requires four 40-watt candelabra bulbs (not included)",
                        Price = 138,
                        Category = "Ceiling Lights",
                        Image = "master_ELEG141.jpg"
                    },
                    new Product
                    {
                        Name = "Justice Design FSN-5555",
                        Delivery = "Y",
                        Specifications = "Dimensions : 12.5L x 12.5W x 5H in",
                        Description = "Contemporary-styled flush mount in dark bronze finish, " +
                        "Incandescent fixture requires (2) 13W GU24 CFL bulbs (included)",
                        Price = 298,
                        Category = "Ceiling Lights",
                        Image = "master_JDG1761.jpg"
                    },
                    new Product
                    {
                        Name = "A and B Home Distressed White Wood Chandelier",
                        Delivery = "Y",
                        Specifications = "Brand: A and B Home, Color: Black, Dimensions: 12.6 diam. x 20.9H in",
                        Description = "Add radiance to your living space with the A and B Home Distressed White Wood Chandelier. " +
                        "This one-light chandelier is handmade from iron and wood, and finished in distressed white " +
                        "for a shabby chic look. With delicate curves and scroll-inspired detail, this chandelier emanates timeless style and charm. One 75-watt bulb is required. ",
                        Price = 103,
                        Category = "Ceiling Lights",
                        Image = "master_ABH2467.jpg"
                    },
                    new Product
                    {
                        Name = "Coral Coast Pleasant Bay 5 ft. Slat Curved-Back Outdoor Wood Bench - Red",
                        Delivery = "Y",
                        Specifications = "Assembly: Assembly Required Brand: Coral Coast",
                        Description = "The Coral Coast Pleasant Bay 5 ft. " +
                        "Slat Curved-Back Outdoor Wood Bench - Red makes a unique addition to any garden, porch, or patio. ",
                        Price = 175,
                        Category = "Outdoor Benches",
                        Image = "inuse_NWF033.jpg"
                    },
                    new Product
                    {
                        Name = "Coral Coast Crossweave Curved Back 4-ft. Metal Garden Bench",
                        Specifications = "Dimensions: 51L x 24W x 32H in.@Weight: 31.9 lbs@Color:Black",
                        Description = "Rugged and rustic, the Coral Coast Crossweave Curved Back 4 ft. " +
                                    "Metal Garden Bench offers a handsome complement to your outdoor décor. " +
                                    "Sturdily constructed of powder-coated, tubular steel, blackened metal " +
                                    "with a weathered bronze finish, this all-weather bench features a traditional, " +
                                    "slatted seat accented by a textured, woven-style back.  ",
                        Price = 71,
                        Category = "Outdoor Benches",
                        Image = "master_ZHEJ003.jpg"
                    },
                    new Product
                    {
                        Name = "Coral Coast Scroll Curved Back 4-ft. Metal Garden Bench",
                        Delivery = "Y",
                        Specifications = "Dimensions: 51L x 24W x 32H in@Weight: 29.81lbs.@Material:Metal",
                        Description = "Transform your outdoor space into an elegant garden scene " +
                                " with the Coral Coast Scroll Curved Back 4 ft. Metal Garden Bench. " +
                                "Sturdily crafted of solid metal, reinforced by a powder-coated, " +
                                "tubular steel frame, this traditional outdoor bench is accented " +
                                "by intricate scrolls and a blackened finish polished in weathered bronze ",
                        Price = 65,
                        Category = "Outdoor Benches",
                        Image = "master_ZHEJ002.jpg"
                    },
                    new Product
                    {
                        Name = "Suncast Ultimate 50-Gallon Resin Patio Storage Bench - PB6700",
                        Delivery = "Y",
                        Specifications  = "Compact and ultra long-lasting, the Suncast Ultimate 50-Gallon Resin Patio Bench " +
                                "adds convenient storage for all your outdoor gear, " +
                                "while doubling up as a handy patio loveseat.",
                        Price = 129,
                        Category = "Outdoor Benches",
                        Image = "master_SUN033.jpg"
                    }
                );
                context.SaveChanges();
            }
        }
    }
}
