﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eFunitureShop.Models
{
    public class FakeProductRepository /* : IProductRepository */
    {
        public IQueryable<Product> 
            Products => new List<Product> {
                new Product { Name = "Morden Chair", Price = 180 },
                new Product { Name = "Minimalistic Plant Pot", Price = 390 },
                new Product { Name = "Night Stand", Price = 95 },
                new Product { Name = "Plant Pot", Price = 18 }

            }.AsQueryable<Product>();
    }
}
